Name - Nishith Agarwal
UID - 1624574357
Email - nishitha@usc.edu

DESCRIPTION:

The program executes a game for A and B to find each other on an n*n board using the shortest path.
 - The main function first reads the input file (input.txt)
 - The Board Size, Costs for 4 operations, A's position, B's position. and Blocks are stores in global variables.
 - The BFS function is called to find the shortest path. The solution is stored in a BFS stack.
 - The UCS function is called to find the shortest path. The solution is stored in a UCS stack.
 - The output function prints the BFS and UCS stacks to output.txt

INSTRUCTIONS:

1. unzip Nishith_Agarwal.zip
2. javac agentGame.java
3. java agentGame
